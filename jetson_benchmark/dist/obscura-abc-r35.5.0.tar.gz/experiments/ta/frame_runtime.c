#include "../camera/frame.c"
